<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre de la etiqueta')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('slug', 'URL amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/stringToSlug/speakingurl.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/stringToSlug/jquery.stringtoslug.min.js')); ?>"></script>
<script>
	$(document).ready(function(){
	    $("#name, #slug").stringToSlug({
	        callback: function(text){
	            $('#slug').val(text);
	        }
	    });
	});
</script>
<?php $__env->stopSection(); ?>