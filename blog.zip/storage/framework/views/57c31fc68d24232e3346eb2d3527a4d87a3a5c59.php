<?php echo e(Form::hidden('user_id', auth()->user()->id)); ?>


<div class="form-group">
	<?php echo e(Form::label('category_id','Categorías')); ?>

	<?php echo e(Form::select('category_id', $categories, null, ['class' => 'form-control'])); ?>

</div>

<div class="form-group">
    <?php echo e(Form::label('name', 'Nombre de la etiqueta')); ?>

    <?php echo e(Form::text('name', null, ['class' => 'form-control', 'id' => 'name'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('slug', 'URL amigable')); ?>

    <?php echo e(Form::text('slug', null, ['class' => 'form-control', 'id' => 'slug'])); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('file', 'Imagen')); ?>

	<?php echo e(Form::file('file')); ?>

</div>
<div class="form-group">
	<?php echo e(Form::label('status', 'Estado')); ?>

	<label>
		<?php echo e(Form::radio('status','PUBLISHED')); ?> Publicado
	</label>
	<label>
		<?php echo e(Form::radio('status','DRAFT')); ?> Borrador
	</label>
</div>
<div class="form-group">
	<?php echo e(Form::label('tags', 'Etiquetas')); ?>

	<div>
		<?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<label>
			<?php echo e(Form::checkbox('tags[]', $tag->id)); ?> <?php echo e($tag->name); ?>

		</label>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div class="form-group">
	<?php echo e(Form::label('excerpt', 'Extracto')); ?>

	<?php echo e(Form::textarea('excerpt', null, ['class' => 'form-control', 'rows' =>'2'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::label('body', 'Descripción')); ?>

    <?php echo e(Form::textarea('body', null, ['class' => 'form-control'])); ?>

</div>
<div class="form-group">
    <?php echo e(Form::submit('Guardar', ['class' => 'btn btn-sm btn-primary'])); ?>

</div>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('vendor/stringToSlug/speakingurl.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/stringToSlug/jquery.stringtoslug.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/ckeditor/ckeditor.js')); ?>"></script>
<script>
	$(document).ready(function(){
	    $("#name, #slug").stringToSlug({
	        callback: function(text){
	            $('#slug').val(text);
	        }
	    });
	});

	CKEDITOR.config.height = 400;
	CKEDITOR.config.width = 'auto';
	CKEDITOR.replace('body');
</script>
<?php $__env->stopSection(); ?>